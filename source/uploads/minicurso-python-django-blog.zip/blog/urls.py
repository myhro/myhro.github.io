from django.conf.urls import patterns, include, url

urlpatterns = patterns('',
    url(r'^$', 'blog.views.home', name='blog_home'),
    url(r'^article/(\d+)$', 'blog.views.article', name='blog_article'),
    url(r'^author/(\d+)$', 'blog.views.home', name='blog_author'),
)
