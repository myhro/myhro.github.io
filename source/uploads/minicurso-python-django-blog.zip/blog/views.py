# -*- coding: utf-8 -*-
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from blog.forms import CommentForm
from blog.models import Article

def home(request, author_id=None):
    if author_id:
        articles = Article.objects.filter(author=author_id)
    else:
        articles = Article.objects.all()
    return render(request, 'blog/home.html', locals())

def article(request, article_id=None):
    a = get_object_or_404(Article, id=article_id)
    form = CommentForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.instance.article = a
        form.save()
        messages.success(request, 'Comentário enviado com sucesso!')
        return redirect(article, article_id)
    return render(request, 'blog/article.html', locals())
