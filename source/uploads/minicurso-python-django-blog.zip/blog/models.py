from django.db import models


class Article(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    pub_date = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey('blog.Author')

    def __unicode__(self):
        return ' - '.join([self.title, self.author.name])

    class Meta:
        ordering = ('-pub_date',)


class Author(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()

    def __unicode__(self):
        return self.name

class Comment(models.Model):
    pub_date = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=100)
    content = models.TextField()
    article = models.ForeignKey('blog.Article')

    def __unicode__(self):
        return self.name
